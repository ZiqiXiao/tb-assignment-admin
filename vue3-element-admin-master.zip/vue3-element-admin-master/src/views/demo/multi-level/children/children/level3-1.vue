<template>
  <div style="padding: 30px">
    <el-alert :closable="false" title="菜单三级-1" type="error" />
  </div>
</template>
