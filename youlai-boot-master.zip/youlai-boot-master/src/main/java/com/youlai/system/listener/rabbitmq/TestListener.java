package com.youlai.system.listener.rabbitmq;

/**
 * @author haoxr
 * @since 0.0.1
 */
public class TestListener {
}
