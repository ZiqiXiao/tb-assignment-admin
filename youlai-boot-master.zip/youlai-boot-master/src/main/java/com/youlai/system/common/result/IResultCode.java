package com.youlai.system.common.result;

/**
 * @author haoxr
 **/
public interface IResultCode {

    String getCode();

    String getMsg();

}
